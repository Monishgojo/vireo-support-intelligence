import { cookies } from 'next/headers'
import { Workspace } from '@/components/vireo/workspace'

export default async function Page() {
  const cookieStore = await cookies()
  const theme = cookieStore.get('vireo-theme')?.value === 'light' ? 'light' : 'dark'
  return <Workspace initialTheme={theme} />
}
