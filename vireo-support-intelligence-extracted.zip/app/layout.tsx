import type { Metadata, Viewport } from 'next'
import { cookies } from 'next/headers'
import { Geist, Geist_Mono } from 'next/font/google'
import './globals.css'

const geist = Geist({ subsets: ['latin'], variable: '--font-geist' })
const mono = Geist_Mono({ subsets: ['latin'], variable: '--font-geist-mono' })

export const metadata: Metadata = {
  title: 'Vireo — Support Intelligence',
  description: 'A clearer picture of your customer experience. Explore support volume, customer conversations, product signals, and data quality in a private, integration-free workspace.',
  icons: { icon: '/vireo-icon.svg' },
  robots: { index: false, follow: false },
}

export const viewport: Viewport = {
  colorScheme: 'dark light',
  themeColor: '#101312',
}

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const cookieStore = await cookies()
  const theme = cookieStore.get('vireo-theme')?.value === 'light' ? 'light' : 'dark'
  return <html lang="en" className={`${theme} ${geist.variable} ${mono.variable}`}><body className="antialiased">{children}</body></html>
}
