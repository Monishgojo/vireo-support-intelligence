'use client'

import { useRef, useState } from 'react'
import { Upload, FileSpreadsheet, ArrowRight, ShieldCheck, LoaderCircle, TriangleAlert, Download } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog'
import { Field, FieldGroup, FieldLabel } from '@/components/ui/field'
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { auditDataset, parseCSV, schemas, suggestMapping, downloadText, type Dataset, type DatasetKind, type Datasets, type Mapping, type Row } from '@/lib/analytics'

export function ImportDialog({ open, onOpenChange, datasets, onImport }: { open: boolean; onOpenChange: (v: boolean) => void; datasets: Datasets; onImport: (dataset: Dataset) => void }) {
  const [kind, setKind] = useState<DatasetKind>('tickets')
  const [file, setFile] = useState<{ name: string; rows: Row[]; headers: string[] } | null>(null)
  const [mapping, setMapping] = useState<Mapping>({})
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [dragging, setDragging] = useState(false)
  const input = useRef<HTMLInputElement>(null)
  async function readFile(upload?: File) {
    if (!upload) return
    setError(''); setBusy(true); setFile(null)
    try {
      if (!upload.name.toLowerCase().endsWith('.csv')) throw new Error('Please choose a .csv file. Documents and ZIP files are not supported in session mode.')
      if (upload.size > 10 * 1024 * 1024) throw new Error('The file exceeds the 10 MB limit. Split it into smaller files before importing.')
      const parsed = parseCSV(await upload.text())
      const guessed = Object.keys(schemas).find(k => upload.name.toLowerCase().startsWith(k)) as DatasetKind | undefined
      const nextKind = guessed ?? kind
      setKind(nextKind); setFile({ name: upload.name, ...parsed }); setMapping(suggestMapping(nextKind, parsed.headers))
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not read this file. Please try again.') }
    finally { setBusy(false); if (input.current) input.current.value = '' }
  }
  const required = schemas[kind].filter(f => f.required)
  const ready = !!file && required.every(f => mapping[f.key])
  const candidate: Dataset | null = ready ? { kind, name: file!.name, ...file!, mapping, importedAt: new Date().toISOString() } : null
  const audit = candidate ? auditDataset(candidate, datasets) : null
  function commit() {
    if (!candidate || !audit?.accepted) return
    const selected = Object.values(mapping).filter(Boolean)
    if (new Set(selected).size !== selected.length) { setError('Each source column can only be mapped once.'); return }
    onImport(candidate); onOpenChange(false); setFile(null); setMapping({}); setError('')
    toast.success(`${candidate.name} imported`, { description: `${audit.accepted.toLocaleString()} accepted records. Available in this session only.` })
  }
  return <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent className="max-h-[88dvh] overflow-y-auto sm:max-w-2xl">
      <DialogHeader><DialogTitle>Bring your data into focus</DialogTitle><DialogDescription>Import a CSV, confirm its columns, and review the validation results.</DialogDescription></DialogHeader>
      <div className="import-steps"><span className={!file ? 'step-current' : ''}>01 <span>Choose file</span></span><ArrowRight /><span className={file ? 'step-current' : ''}>02 <span>Map & validate</span></span><ArrowRight /><span>03 <span>Explore</span></span></div>
      <FieldGroup><Field><FieldLabel htmlFor="dataset-kind">Dataset</FieldLabel><select id="dataset-kind" className="native-select" value={kind} onChange={e => { const next = e.target.value as DatasetKind; setKind(next); if (file) setMapping(suggestMapping(next, file.headers)); setError('') }}>{Object.keys(schemas).map(k => <option key={k} value={k}>{k[0].toUpperCase() + k.slice(1)}</option>)}</select></Field></FieldGroup>
      <div className={`upload-zone ${dragging ? 'dragging' : ''}`} onDragOver={e => { e.preventDefault(); setDragging(true) }} onDragLeave={() => setDragging(false)} onDrop={e => { e.preventDefault(); setDragging(false); void readFile(e.dataTransfer.files[0]) }}>
        <div className="upload-icon">{busy ? <LoaderCircle className="animate-spin" /> : file ? <FileSpreadsheet /> : <Upload />}</div>
        <strong>{file ? file.name : 'Drop your CSV file here'}</strong>
        <p>{file ? `${file.rows.length.toLocaleString()} rows · ${file.headers.length} columns` : 'Up to 10 MB and 50,000 records per file'}</p>
        <Button variant="outline" onClick={() => input.current?.click()} disabled={busy}>{file ? 'Choose a different file' : 'Browse files'}<ArrowRight data-icon="inline-end" /></Button>
        <input ref={input} data-testid="csv-input" className="sr-only" type="file" accept=".csv,text/csv" aria-label="Upload CSV file" onChange={e => void readFile(e.target.files?.[0])} />
      </div>
      {error && <Alert variant="destructive"><TriangleAlert /><AlertTitle>File needs attention</AlertTitle><AlertDescription>{error}</AlertDescription></Alert>}
      {file && <><div className="flex items-center justify-between"><h3 className="text-sm font-medium">Confirm your column mapping</h3><Badge variant="outline">Required fields marked *</Badge></div><p className="text-xs text-muted-foreground">Suggestions are not source definitions. Check them against your dataset documentation. Dates must be YYYY-MM-DD or ISO timestamps with a timezone.</p><FieldGroup className="grid grid-cols-1 gap-3 sm:grid-cols-2">{schemas[kind].map(field => <Field key={field.key}><FieldLabel htmlFor={`map-${field.key}`}>{field.label}{field.required ? ' *' : ''}</FieldLabel><select id={`map-${field.key}`} className="native-select" value={mapping[field.key] || ''} onChange={e => { setMapping(m => ({ ...m, [field.key]: e.target.value })); setError('') }}><option value="">{field.required ? 'Select a column' : 'Not available'}</option>{file.headers.map(h => <option key={h} value={h}>{h}</option>)}</select></Field>)}</FieldGroup>
      {audit && <Alert><ShieldCheck /><AlertTitle>{audit.accepted.toLocaleString()} of {audit.rows.toLocaleString()} records accepted</AlertTitle><AlertDescription>{audit.rows - audit.accepted} excluded for missing IDs/status, duplicate IDs, or invalid opening dates. {audit.invalidClosures} invalid closure dates. {audit.orphans} unmatched references. {audit.unmappedReferences} references cannot be checked until related files are imported.</AlertDescription></Alert>}
      {datasets[kind] && <p className="text-xs text-warning">This replaces the current {kind} dataset for this session, rather than appending records.</p>}</>}
      {!file && <Button variant="ghost" onClick={() => downloadText(`${kind}-header-template.csv`, schemas[kind].map(f => f.aliases?.[0] ?? f.key).join(',') + '\n')}><Download data-icon="inline-start" />Download a header-only template</Button>}
      <div className="privacy-note"><ShieldCheck /><span>Processed in this browser. No uploads to a server. Data clears on reload.</span></div>
      <DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button disabled={!ready || !audit?.accepted || busy} onClick={commit}>Import & explore<ArrowRight data-icon="inline-end" /></Button></DialogFooter>
    </DialogContent>
  </Dialog>
}
