import Papa from 'papaparse'

export type DatasetKind = 'tickets' | 'agents' | 'products' | 'orders' | 'customers'
export type Row = Record<string, string>
export type Mapping = Record<string, string>
export type Dataset = { kind: DatasetKind; name: string; headers: string[]; rows: Row[]; mapping: Mapping; importedAt: string }
export type Datasets = Partial<Record<DatasetKind, Dataset>>
export type FieldSpec = { key: string; label: string; required?: boolean; aliases?: string[] }
export const schemas: Record<DatasetKind, FieldSpec[]> = {
  tickets: [
    { key: 'id', label: 'Ticket ID', required: true, aliases: ['ticket_id', 'id'] },
    { key: 'created', label: 'Opened at', required: true, aliases: ['created_at', 'opened_at', 'created_date', 'date'] },
    { key: 'status', label: 'Status', required: true, aliases: ['status', 'ticket_status'] },
    { key: 'closed', label: 'Closed at', aliases: ['closed_at', 'resolved_at', 'closed_date'] },
    { key: 'category', label: 'Existing complaint category', aliases: ['category', 'primary_category', 'complaint_category'] },
    { key: 'product', label: 'Product ID', aliases: ['product_id'] },
    { key: 'agent', label: 'Agent ID', aliases: ['agent_id', 'assigned_agent_id'] },
    { key: 'customer', label: 'Customer ID', aliases: ['customer_id'] },
    { key: 'order', label: 'Order ID', aliases: ['order_id'] },
    { key: 'message', label: 'Opening message', aliases: ['opening_message', 'customer_message', 'description', 'message'] },
    { key: 'note', label: 'Closing note', aliases: ['closing_note', 'agent_note', 'resolution_notes'] },
  ],
  agents: [{ key: 'id', label: 'Agent ID', required: true, aliases: ['agent_id', 'id'] }, { key: 'name', label: 'Agent name', required: true, aliases: ['agent_name', 'name'] }],
  products: [{ key: 'id', label: 'Product ID', required: true, aliases: ['product_id', 'id'] }, { key: 'name', label: 'Product name', required: true, aliases: ['product_name', 'name', 'model'] }],
  orders: [{ key: 'id', label: 'Order ID', required: true, aliases: ['order_id', 'id'] }, { key: 'customer', label: 'Customer ID', aliases: ['customer_id'] }, { key: 'product', label: 'Product ID', aliases: ['product_id'] }],
  customers: [{ key: 'id', label: 'Customer ID', required: true, aliases: ['customer_id', 'id'] }],
}
export function parseCSV(text: string): { headers: string[]; rows: Row[] } {
  const result = Papa.parse<string[]>(text.replace(/^\uFEFF/, ''), { skipEmptyLines: 'greedy' })
  if (result.errors.length) throw new Error(`Invalid CSV: ${result.errors[0].message}`)
  const [rawHeaders, ...data] = result.data
  if (!rawHeaders?.length || rawHeaders.length < 2) throw new Error('Use a CSV with a header row and at least two columns.')
  const headers = rawHeaders.map(h => h.trim())
  if (headers.some(h => !h) || new Set(headers.map(h => h.toLowerCase())).size !== headers.length) throw new Error('Column names must be non-empty and unique.')
  if (!data.length) throw new Error('This file has headers but no records. Add real records before importing.')
  if (data.length > 50000) throw new Error('Session mode supports up to 50,000 records per file.')
  const bad = data.findIndex(r => r.length !== headers.length)
  if (bad >= 0) throw new Error(`Row ${bad + 2} has a different number of columns. Check commas and quoted values.`)
  return { headers, rows: data.map(values => Object.fromEntries(headers.map((h, i) => [h, values[i].trim()]))) }
}
export function suggestMapping(kind: DatasetKind, headers: string[]): Mapping {
  return Object.fromEntries(schemas[kind].map(f => [f.key, headers.find(h => f.aliases?.includes(h.toLowerCase().replace(/[ -]/g, '_'))) ?? '']))
}
export function value(dataset: Dataset, row: Row, key: string) { return row[dataset.mapping[key]]?.trim() ?? '' }
export function validDate(raw: string): string | null {
  if (!/^\d{4}-\d{2}-\d{2}(?:$|T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$)/.test(raw)) return null
  const date = new Date(raw)
  const datePart = raw.slice(0, 10)
  if (Number.isNaN(date.getTime()) || new Date(datePart).toISOString().slice(0, 10) !== datePart) return null
  const year = date.getUTCFullYear()
  return year >= 1970 && year <= 2100 ? date.toISOString() : null
}
export function weekStart(date: string) {
  const d = new Date(date); d.setUTCHours(0, 0, 0, 0)
  d.setUTCDate(d.getUTCDate() - (d.getUTCDay() + 6) % 7)
  return d.toISOString().slice(0, 10)
}
export type Ticket = { id: string; created: string; closed: string | null; status: string; category: string; product: string; agent: string; message: string; note: string }
export type Audit = { kind: DatasetKind; rows: number; accepted: number; missingIds: number; duplicateIds: number; invalidDates: number; missingStatuses: number; missingText: number; invalidClosures: number; orphans: number; unmappedReferences: number }
export function auditDataset(dataset: Dataset, datasets: Datasets): Audit {
  const audit: Audit = { kind: dataset.kind, rows: dataset.rows.length, accepted: 0, missingIds: 0, duplicateIds: 0, invalidDates: 0, missingStatuses: 0, missingText: 0, invalidClosures: 0, orphans: 0, unmappedReferences: 0 }
  const seen = new Set<string>()
  const referenceKeys = { agent: 'agents', product: 'products', customer: 'customers', order: 'orders' } as const
  const references = Object.entries(referenceKeys).map(([key, kind]) => {
    const target = datasets[kind]
    return { key, ids: target ? new Set(target.rows.map(r => value(target, r, 'id')).filter(Boolean)) : null }
  })
  for (const row of dataset.rows) {
    let valid = true
    const id = value(dataset, row, 'id')
    if (!id) { audit.missingIds++; valid = false }
    else if (seen.has(id)) { audit.duplicateIds++; valid = false }
    else seen.add(id)
    if (dataset.kind === 'tickets') {
      const created = validDate(value(dataset, row, 'created'))
      const closedRaw = value(dataset, row, 'closed')
      const closed = validDate(closedRaw)
      if (!created) { audit.invalidDates++; valid = false }
      if (!value(dataset, row, 'status')) { audit.missingStatuses++; valid = false }
      if (dataset.mapping.message && !value(dataset, row, 'message')) audit.missingText++
      if (closedRaw && (!closed || (created && closed < created))) audit.invalidClosures++
    }
    for (const ref of references) {
      if (!dataset.mapping[ref.key]) continue
      const foreignId = value(dataset, row, ref.key)
      if (!foreignId) continue
      if (!ref.ids) audit.unmappedReferences++
      else if (!ref.ids.has(foreignId)) audit.orphans++
    }
    if (valid) audit.accepted++
  }
  return audit
}
export function ticketsFrom(datasets: Datasets): Ticket[] {
  const d = datasets.tickets
  if (!d) return []
  const seen = new Set<string>()
  return d.rows.flatMap(row => {
    const get = (key: string) => value(d, row, key)
    const id = get('id'), created = validDate(get('created')), status = get('status').toLowerCase()
    if (!id || seen.has(id)) return []
    seen.add(id)
    if (!created || !status) return []
    const closedDate = validDate(get('closed'))
    return [{ id, created, status, closed: closedDate && closedDate >= created ? closedDate : null, category: get('category') || 'Unclassified', product: get('product') || 'Unassigned', agent: get('agent') || 'Unassigned', message: maskText(get('message')), note: maskText(get('note')) }]
  })
}
export function maskText(text: string) {
  return text.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[email hidden]').replace(/(?:\+?\d[\d ()-]{7,}\d)/g, '[number hidden]')
}
export const isClosed = (t: Ticket) => ['closed', 'resolved'].includes(t.status)
export type Filters = { start: string; end: string; product: string; category: string; agent: string; query: string }
export const emptyFilters: Filters = { start: '', end: '', product: '', category: '', agent: '', query: '' }
export function filterTickets(tickets: Ticket[], filters: Filters, dateField: 'created' | 'closed' = 'created') {
  return tickets.filter(t => {
    const date = t[dateField]?.slice(0, 10)
    return (!filters.start || !!date && date >= filters.start) && (!filters.end || !!date && date <= filters.end) && (!filters.product || t.product === filters.product) && (!filters.category || t.category === filters.category) && (!filters.agent || t.agent === filters.agent) && (!filters.query || `${t.id} ${t.message} ${t.note}`.toLowerCase().includes(filters.query.toLowerCase()))
  })
}
export function weeklyCounts(tickets: Ticket[]) {
  if (!tickets.length) return []
  const counts = new Map<string, number>()
  for (const t of tickets) { const week = weekStart(t.created); counts.set(week, (counts.get(week) ?? 0) + 1) }
  const dates = [...counts.keys()].sort(), result = []
  const current = new Date(dates[0]), end = new Date(dates[dates.length - 1])
  while (current <= end) {
    const week = current.toISOString().slice(0, 10)
    result.push({ week, tickets: counts.get(week) ?? 0 })
    current.setUTCDate(current.getUTCDate() + 7)
  }
  return result
}
export function groupCounts(tickets: Ticket[], key: 'category' | 'product' | 'agent') {
  const counts = new Map<string, number>()
  tickets.forEach(t => counts.set(t[key], (counts.get(t[key]) ?? 0) + 1))
  return [...counts].map(([name, count]) => ({ name, count, share: tickets.length ? count / tickets.length * 100 : 0 })).sort((a, b) => b.count - a.count || a.name.localeCompare(b.name))
}
export function lookupName(datasets: Datasets, kind: 'agents' | 'products', id: string) {
  const d = datasets[kind]
  const row = d?.rows.find(r => value(d, r, 'id') === id)
  return d && row ? maskText(value(d, row, 'name')) || id : id
}
export function toCSV(rows: Record<string, unknown>[]) {
  return Papa.unparse(rows, { escapeFormulae: true })
}
export function downloadText(name: string, content: string, type = 'text/csv;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([content], { type }))
  const a = document.createElement('a'); a.href = url; a.download = name; a.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
export function formatDate(date: string) { return new Intl.DateTimeFormat('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(new Date(date)) }
export function reportText(tickets: Ticket[], datasets: Datasets) {
  const weeks = weeklyCounts(tickets)
  return `VIREO SUPPORT INTELLIGENCE\nSession analysis — ${new Date().toISOString()}\n\nFiltered accepted tickets: ${tickets.length}\nObserved calendar weeks (including gaps): ${weeks.length}\nAverage per observed week: ${weeks.length ? (tickets.length / weeks.length).toFixed(1) : 'Not available'}\nClosed or resolved status: ${tickets.filter(isClosed).length}\n\nSOURCE FILES\n${Object.values(datasets).map(d => `${d.name}: ${d.rows.length} source rows; imported ${d.importedAt}`).join('\n')}\n\nLIMITATIONS\nCounts use imported records only, not a claim of complete coverage. UTC weeks start Monday. The first occurrence of each ID is retained; invalid records are excluded. Categories are imported labels, not AI predictions. Financial impact, business targets and AI accuracy are unavailable without source evidence and human validation. No files are saved or sent to a server.\n`
}
